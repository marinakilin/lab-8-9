# recipe-planner-android
## Android Client for Recipe Planner API. 
Search and filter recipes, get ingredients and shopping lists. Register to save recipes for later or to add them to your meal calendar. 
### Recipe Planner API uses third-party [Spoonacular API](https://spoonacular.com/food-api)
