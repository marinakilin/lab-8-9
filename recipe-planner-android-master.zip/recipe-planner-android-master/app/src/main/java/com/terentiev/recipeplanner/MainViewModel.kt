package com.terentiev.recipeplanner

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.terentiev.recipeplanner.data.AppRepository

class MainViewModel : ViewModel() {

}