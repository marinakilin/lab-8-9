package com.terentiev.recipeplanner.data.retrofit

data class AuthResponse(val username: String, val token: String)
