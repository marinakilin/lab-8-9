package com.terentiev.recipeplanner.data.retrofit

data class AuthRequest(val username: String, val password: String)
